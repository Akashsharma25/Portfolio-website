import React from 'react'
import HomePage from './pages/home'

const App = () => {
  return (
    <div>
      <HomePage/>
    </div>
  )
}

export default App
