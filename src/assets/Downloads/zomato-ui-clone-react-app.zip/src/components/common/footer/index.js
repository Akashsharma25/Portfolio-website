import React from 'react'

const Footer = () => {
  return (
    <div className='absolute-center'>
     Made with Rage by Akash 🏆
    </div>
  )
}

export default Footer;
