export const diningOut = [
        {
            "type": "restaurant",
            "info": {
                "resId": 20872966,
                "name": "Golden Bites Restaurant",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/6/20872966/39aef31d0c9e71ca39fc3fc662c481bb_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/6/20872966/39aef31d0c9e71ca39fc3fc662c481bb_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/6/20872966/c48b197567dd8084250f31a03f6f6260_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "0",
                    "rating_text": "-",
                    "rating_subtitle": "Not rated",
                    "rating_color": "CBCBCB",
                    "votes": "2",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": {
                        "text": "Newly Opened",
                        "color": "#FFFFFF",
                        "bgColor": "#F4A266",
                        "bgColorV2": {
                            "type": "green",
                            "tint": "100"
                        },
                        "subtitle": "OUTLET",
                        "ratingV2": "New"
                    },
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Dining",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "",
                            "reviewCount": "2",
                            "reviewTextSmall": "2 Reviews",
                            "subtext": "Does not offer Delivery",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDelivery": true
                        }
                    }
                },
                "cft": {
                    "text": "₹500 for two"
                },
                "cfo": {
                    "text": "₹200 for one"
                },
                "locality": {
                    "name": "Zeta 1, Greater Noida",
                    "address": "A-121, Ground Floor, Block A, Zeta 1, Greater Noida",
                    "localityUrl": "ncr/zeta-1-restaurants"
                },
                "timing": {
                    "text": "Opens at 11am",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                        "name": "Chinese"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiOTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/street-food/",
                        "name": "Street Food"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹500 for two"
                }
            },
            "order": [],
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/golden-bites-restaurant-zeta-1-greater-noida/info",
                "clickActionDeeplink": ""
            },
            "distance": "2.8 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20872966\",\"element_type\":\"listing\",\"rank\":490}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 20749890,
                "name": "Nainital Momos MultiGrain Atta Momo No Maida",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/0/20749890/520c8ca674772b65f1809c2b464cf814_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/0/20749890/520c8ca674772b65f1809c2b464cf814_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/0/20749890/806af75dc6219525e4c1429305e22522_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "3.4",
                    "rating_text": "3.4",
                    "rating_subtitle": "Average",
                    "rating_color": "CDD614",
                    "votes": "21",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "",
                            "reviewCount": "3",
                            "reviewTextSmall": "3 Reviews",
                            "subtext": "Does not offer Dining",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "3.4",
                            "reviewCount": "18",
                            "reviewTextSmall": "18 Reviews",
                            "subtext": "18 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "3.4",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "500"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹500 for two"
                },
                "cfo": {
                    "text": "₹200 for one"
                },
                "locality": {
                    "name": "Alpha 2, Greater Noida",
                    "address": "Shop Lgf-09, Satytam Complex 2, G.B.Nagar, Alpha 2, Greater Noida",
                    "localityUrl": "ncr/alpha-2-restaurants"
                },
                "timing": {
                    "text": "Opens at 11:15am",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTA1MVwiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/momos/",
                        "name": "Momos"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                        "name": "Chinese"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTYzXCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/tea/",
                        "name": "Tea"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTA2NlwiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/shake/",
                        "name": "Shake"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/beverages/",
                        "name": "Beverages"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹500 for two"
                }
            },
            "order": [],
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/nainital-momos-multigrain-atta-momo-no-maida-alpha-2-greater-noida/info",
                "clickActionDeeplink": ""
            },
            "distance": "998 m",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20749890\",\"element_type\":\"listing\",\"rank\":491}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 20035325,
                "name": "Apna Restaurant",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/5/20035325/c34e0cee90e1a91360be1ab2ff49fad1_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/5/20035325/c34e0cee90e1a91360be1ab2ff49fad1_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/5/20035325/0f2a92f225f6e1d46d199af56aa98d57_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "3.9",
                    "rating_text": "3.9",
                    "rating_subtitle": "Good",
                    "rating_color": "9ACD32",
                    "votes": "116",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "",
                            "reviewCount": "2",
                            "reviewTextSmall": "2 Reviews",
                            "subtext": "Does not offer Dining",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "3.9",
                            "reviewCount": "114",
                            "reviewTextSmall": "114 Reviews",
                            "subtext": "114 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "3.9",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "600"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹400 for two"
                },
                "cfo": {
                    "text": "₹200 for one"
                },
                "locality": {
                    "name": "Knowledge Park, Greater Noida",
                    "address": "Tugalpur Ja Plaza, Pari Chowk, Knowledge Park, Greater Noida",
                    "localityUrl": "ncr/knowledge-park-restaurants"
                },
                "timing": {
                    "text": "Opens at 12noon",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNzVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/mughlai/",
                        "name": "Mughlai"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                        "name": "Chinese"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹400 for two"
                }
            },
            "order": [],
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/apna-restaurant-knowledge-park-greater-noida/info",
                "clickActionDeeplink": ""
            },
            "distance": "1.7 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20035325\",\"element_type\":\"listing\",\"rank\":492}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 20247535,
                "name": "Sher E Punjab",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/5/20247535/c59249d5d2626248f58d28920876daeb_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/5/20247535/c59249d5d2626248f58d28920876daeb_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": false
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "0",
                    "rating_text": "-",
                    "rating_subtitle": "Not rated",
                    "rating_color": "CBCBCB",
                    "votes": "0",
                    "subtext": "REVIEW",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Dining",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Delivery",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹450 for two"
                },
                "cfo": {
                    "text": "₹200 for one"
                },
                "locality": {
                    "name": "Surajpur, Noida",
                    "address": "Near Shareen Farm, Surajpur, Noida",
                    "localityUrl": "ncr/surajpur-noida-restaurants"
                },
                "timing": {
                    "text": "Opens at 11am",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/fast-food/",
                        "name": "Fast Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹450 for two"
                }
            },
            "order": [],
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/sher-e-punjab-surajpur-noida/info",
                "clickActionDeeplink": ""
            },
            "distance": "4.2 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20247535\",\"element_type\":\"listing\",\"rank\":493}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 19513749,
                "name": "Four Square",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/9/19513749/fc70927bce2f8ffc52ebb0a278a1d0ab_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/9/19513749/fc70927bce2f8ffc52ebb0a278a1d0ab_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/9/19513749/6f9908bb86f47a5f201d181f14633334_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.0",
                    "rating_text": "4.0",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "15",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Dining",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "4.0",
                            "reviewCount": "15",
                            "reviewTextSmall": "15 Reviews",
                            "subtext": "15 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "4.0",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹350 for two"
                },
                "cfo": {
                    "text": "₹150 for one"
                },
                "locality": {
                    "name": "Knowledge Park, Greater Noida",
                    "address": "10/3, 2nd Floor, Tugalpur, Knowledge Park, Greater Noida",
                    "localityUrl": "ncr/knowledge-park-restaurants"
                },
                "timing": {
                    "text": "Opening hours not available",
                    "color": ""
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                        "name": "Chinese"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/south-indian/",
                        "name": "South Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/fast-food/",
                        "name": "Fast Food"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹350 for two"
                }
            },
            "order": [],
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/four-square-knowledge-park-greater-noida/info",
                "clickActionDeeplink": ""
            },
            "distance": "1.6 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"19513749\",\"element_type\":\"listing\",\"rank\":494}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 19654840,
                "name": "Anna Junction",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/0/19654840/d206166c686527c67947cd310fd391ac_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/0/19654840/d206166c686527c67947cd310fd391ac_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/0/19654840/a40b9452336861a9c920aa20c2027efa_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "0",
                    "rating_text": "-",
                    "rating_subtitle": "Not rated",
                    "rating_color": "CBCBCB",
                    "votes": "5",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "",
                            "reviewCount": "3",
                            "reviewTextSmall": "3 Reviews",
                            "subtext": "Does not offer Dining",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "",
                            "reviewCount": "2",
                            "reviewTextSmall": "2 Reviews",
                            "subtext": "Does not offer Delivery",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹300 for two"
                },
                "cfo": {
                    "text": "₹150 for one"
                },
                "locality": {
                    "name": "Alpha 1, Greater Noida",
                    "address": "D-1, G-12, Krishna Apra Plaza, Commercial Belt, Alpha 1, Greater Noida",
                    "localityUrl": "ncr/alpha-1-restaurants"
                },
                "timing": {
                    "text": "Opens at 10:30am",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/south-indian/",
                        "name": "South Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/fast-food/",
                        "name": "Fast Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/beverages/",
                        "name": "Beverages"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹300 for two"
                }
            },
            "order": [],
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/anna-junction-1-alpha-1-greater-noida/info",
                "clickActionDeeplink": ""
            },
            "distance": "1.1 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"19654840\",\"element_type\":\"listing\",\"rank\":495}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 20642005,
                "name": "CP 24 Kitchen",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/5/20642005/957f46b0acb6ad9658bbe61f218c4c3c_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/5/20642005/957f46b0acb6ad9658bbe61f218c4c3c_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/5/20642005/bcf9680c6e8dd3af7fb1fb049b696351_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.0",
                    "rating_text": "4.0",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "10",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Dining",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "4.0",
                            "reviewCount": "10",
                            "reviewTextSmall": "10 Reviews",
                            "subtext": "10 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "4.0",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹1,400 for two"
                },
                "cfo": {
                    "text": "₹600 for one"
                },
                "locality": {
                    "name": "Chi 1, Greater Noida",
                    "address": "BA 001, Golf Link 1, Chi 1, Greater Noida",
                    "localityUrl": "ncr/chi-1-restaurants"
                },
                "timing": {
                    "text": "Opens at 8am",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                        "name": "Chinese"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTA2NFwiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/pasta/",
                        "name": "Pasta"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/continental/",
                        "name": "Continental"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/fast-food/",
                        "name": "Fast Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/desserts/",
                        "name": "Desserts"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹1,400 for two"
                }
            },
            "order": [],
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/cp-24-kitchen-chi-1-greater-noida/info",
                "clickActionDeeplink": ""
            },
            "distance": "2.8 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20642005\",\"element_type\":\"listing\",\"rank\":496}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 20543586,
                "name": "Bikaner Family Restaurant Sweets & Bake",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/6/20543586/d9fbd18abac8a60466a719de330f3898_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/6/20543586/d9fbd18abac8a60466a719de330f3898_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/6/20543586/37750871991fc4a1dfb8c9013cab2498_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "3.6",
                    "rating_text": "3.6",
                    "rating_subtitle": "Good",
                    "rating_color": "9ACD32",
                    "votes": "194",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Dining",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "3.6",
                            "reviewCount": "194",
                            "reviewTextSmall": "194 Reviews",
                            "subtext": "194 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "3.6",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "600"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹400 for two"
                },
                "cfo": {
                    "text": "₹200 for one"
                },
                "locality": {
                    "name": "Gamma 2, Greater Noida",
                    "address": "Shop 2, Main Road, Surajpur, Gamma 2, Greater Noida",
                    "localityUrl": "ncr/gamma-2-restaurants"
                },
                "timing": {
                    "text": "Opens at 9:30am",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/south-indian/",
                        "name": "South Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                        "name": "Chinese"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹400 for two"
                }
            },
            "order": [],
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/bikaner-family-restaurant-sweets-bake-gamma-2-greater-noida/info",
                "clickActionDeeplink": ""
            },
            "distance": "4.2 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20543586\",\"element_type\":\"listing\",\"rank\":497}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 20784604,
                "name": "Buraans Restaurant",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/4/20784604/893a8ae8870f5961e2a91f76735163b5_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/4/20784604/893a8ae8870f5961e2a91f76735163b5_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": false
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "0",
                    "rating_text": "-",
                    "rating_subtitle": "Not rated",
                    "rating_color": "CBCBCB",
                    "votes": "0",
                    "subtext": "REVIEW",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Dining",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Delivery",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹300 for two"
                },
                "cfo": {
                    "text": "₹150 for one"
                },
                "locality": {
                    "name": "Gamma 1, Greater Noida",
                    "address": "9, Block E, Near Chandila, Gamma 1, Greater Noida",
                    "localityUrl": "ncr/gamma-1-restaurants"
                },
                "timing": {
                    "text": "Opens at 11am",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                        "name": "Chinese"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTA1MVwiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/momos/",
                        "name": "Momos"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹300 for two"
                }
            },
            "order": [],
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/buraans-restaurant-gamma-1-greater-noida/info",
                "clickActionDeeplink": ""
            },
            "distance": "777 m",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20784604\",\"element_type\":\"listing\",\"rank\":498}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 19257996,
                "name": "Nazeer Delicacies",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/6/19257996/fc70927bce2f8ffc52ebb0a278a1d0ab_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/6/19257996/fc70927bce2f8ffc52ebb0a278a1d0ab_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/6/19257996/fc70927bce2f8ffc52ebb0a278a1d0ab_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "0",
                    "rating_text": "-",
                    "rating_subtitle": "Not rated",
                    "rating_color": "CBCBCB",
                    "votes": "0",
                    "subtext": "REVIEW",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Dining",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Delivery",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹600 for two"
                },
                "cfo": {
                    "text": "₹250 for one"
                },
                "locality": {
                    "name": "Knowledge Park, Greater Noida",
                    "address": "8, Ground Floor, Vardhman Valley, Near Sharda Gol Chakkar, Knowledge Park 3, Greater Noida",
                    "localityUrl": "ncr/knowledge-park-restaurants"
                },
                "timing": {
                    "text": "Opens at 10am",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTc4XCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/kebab/",
                        "name": "Kebab"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNzVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/mughlai/",
                        "name": "Mughlai"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹600 for two"
                }
            },
            "order": [],
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/nazeer-delicacies-knowledge-park-greater-noida/info",
                "clickActionDeeplink": ""
            },
            "distance": "2.7 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"19257996\",\"element_type\":\"listing\",\"rank\":499}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 20718093,
                "name": "Spicy Bite Café & Restaurant",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/3/20718093/dd774b1648dcf1f86436a4bc20aa3366_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/3/20718093/dd774b1648dcf1f86436a4bc20aa3366_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/3/20718093/f2093268065544a5c47fae2bfb92d3eb_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "2.1",
                    "rating_text": "2.1",
                    "rating_subtitle": "Poor",
                    "rating_color": "FF7800",
                    "votes": "7",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Dining",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "2.1",
                            "reviewCount": "7",
                            "reviewTextSmall": "7 Reviews",
                            "subtext": "7 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "2.1",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "orange",
                                "tint": "300"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹500 for two"
                },
                "cfo": {
                    "text": "₹200 for one"
                },
                "locality": {
                    "name": "Knowledge Park, Greater Noida",
                    "address": "D21, Opposite IIMT College, Knowledge Park, Greater Noida",
                    "localityUrl": "ncr/knowledge-park-restaurants"
                },
                "timing": {
                    "text": "Opens at 11am",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                        "name": "Chinese"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/fast-food/",
                        "name": "Fast Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/beverages/",
                        "name": "Beverages"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹500 for two"
                }
            },
            "order": [],
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/spicy-bite-café-restaurant-1-knowledge-park-greater-noida/info",
                "clickActionDeeplink": ""
            },
            "distance": "1.5 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20718093\",\"element_type\":\"listing\",\"rank\":500}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 19652815,
                "name": "Machaan Fine Dine Restaurant- Blue Bell Hotel",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/5/19652815/cd5412e86aa64f27e24587c4667de558_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/chains/5/19652815/cd5412e86aa64f27e24587c4667de558_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/5/19652815/2bd99d11e9073418ea4c200272202734_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "0",
                    "rating_text": "-",
                    "rating_subtitle": "Not rated",
                    "rating_color": "CBCBCB",
                    "votes": "2",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "",
                            "reviewCount": "1",
                            "reviewTextSmall": "1 Reviews",
                            "subtext": "Does not offer Dining",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "",
                            "reviewCount": "1",
                            "reviewTextSmall": "1 Reviews",
                            "subtext": "Does not offer Delivery",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹500 for two"
                },
                "cfo": {
                    "text": "₹200 for one"
                },
                "locality": {
                    "name": "Knowledge Park, Greater Noida",
                    "address": "24 A/3, Knowledge Park, Greater Noida",
                    "localityUrl": "ncr/knowledge-park-restaurants"
                },
                "timing": {
                    "text": "Opens at 11am",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                        "name": "Chinese"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/beverages/",
                        "name": "Beverages"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹500 for two"
                }
            },
            "order": [],
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/machaan-fine-dine-restaurant-blue-bell-hotel-knowledge-park-greater-noida/info",
                "clickActionDeeplink": ""
            },
            "distance": "1.4 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"19652815\",\"element_type\":\"listing\",\"rank\":501}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        }
    ,
    {
        "type": "restaurant",
        "info": {
            "resId": 19546552,
            "name": "Kesar Foods",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/2/19546552/6b18aa1ba9809d7e8c5d6ef2263ed854_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/2/19546552/6b18aa1ba9809d7e8c5d6ef2263ed854_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": "https://b.zmtcdn.com/data/pictures/2/19546552/4b19346feb1866f0fa48173e302af8cb_o2_featured_v2.jpg"
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "3.6",
                "rating_text": "3.6",
                "rating_subtitle": "Good",
                "rating_color": "9ACD32",
                "votes": "15",
                "subtext": "REVIEWS",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "",
                        "reviewCount": "2",
                        "reviewTextSmall": "2 Reviews",
                        "subtext": "Does not offer Dining",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "3.6",
                        "reviewCount": "13",
                        "reviewTextSmall": "13 Reviews",
                        "subtext": "13 Delivery Reviews",
                        "color": "#E23744",
                        "ratingV2": "3.6",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "green",
                            "tint": "600"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹250 for two"
            },
            "cfo": {
                "text": "₹100 for one"
            },
            "locality": {
                "name": "Beta Plaza, Greater Noida",
                "address": "1, Suraj Pradhan Market, PNB Bank Wali Gali, Tugalpur, Near Ansal Plaza, Knowledge Park, Greater Noida",
                "localityUrl": "ncr/restaurants/in/beta-plaza"
            },
            "timing": {
                "text": "",
                "color": ""
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                    "name": "North Indian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                    "name": "Chinese"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/fast-food/",
                    "name": "Fast Food"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/beverages/",
                    "name": "Beverages"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹250 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/kesar-foods-knowledge-park-greater-noida/info",
            "clickActionDeeplink": ""
        },
        "distance": "408 m",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"19546552\",\"element_type\":\"listing\",\"rank\":154}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 20153517,
            "name": "Aggarwal Sweets And Snacks",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/7/20153517/07a8467acb253923115972083ee87a61_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/7/20153517/07a8467acb253923115972083ee87a61_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": "https://b.zmtcdn.com/data/pictures/7/20153517/bae061afa2fc88fe8d5bf7d3af769fdf_o2_featured_v2.jpg"
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "3.6",
                "rating_text": "3.6",
                "rating_subtitle": "Good",
                "rating_color": "9ACD32",
                "votes": "125",
                "subtext": "REVIEWS",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Dining",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "3.6",
                        "reviewCount": "125",
                        "reviewTextSmall": "125 Reviews",
                        "subtext": "125 Delivery Reviews",
                        "color": "#E23744",
                        "ratingV2": "3.6",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "green",
                            "tint": "600"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹400 for two"
            },
            "cfo": {
                "text": "₹200 for one"
            },
            "locality": {
                "name": "Beta 1, Greater Noida",
                "address": "Shop 25, 2nd Floor, Beta Plaza, Beta 1, Greater Noida",
                "localityUrl": "ncr/beta-1-restaurants"
            },
            "timing": {
                "text": "Closes in 1 hour 31 minutes",
                "color": "#e5521f"
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAxNVwiXX0iXQ%3D%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/mithai/",
                    "name": "Mithai"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/fast-food/",
                    "name": "Fast Food"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiOTBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/street-food/",
                    "name": "Street Food"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹400 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/aggarwal-sweets-and-snacks-2-beta-1-greater-noida/info",
            "clickActionDeeplink": ""
        },
        "distance": "425 m",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20153517\",\"element_type\":\"listing\",\"rank\":155}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 19523455,
            "name": "Food King",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/5/19523455/59a0541aaf9ca8c67104b6618f61621c_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/5/19523455/59a0541aaf9ca8c67104b6618f61621c_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": "https://b.zmtcdn.com/data/pictures/5/19523455/6905b0cd6bde7e0ebbcd52a374e3ae11_o2_featured_v2.jpg"
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "3.8",
                "rating_text": "3.8",
                "rating_subtitle": "Good",
                "rating_color": "9ACD32",
                "votes": "28",
                "subtext": "REVIEWS",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Dining",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "3.8",
                        "reviewCount": "28",
                        "reviewTextSmall": "28 Reviews",
                        "subtext": "28 Delivery Reviews",
                        "color": "#E23744",
                        "ratingV2": "3.8",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "green",
                            "tint": "600"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹600 for two"
            },
            "cfo": {
                "text": "₹250 for one"
            },
            "locality": {
                "name": "Beta 1, Greater Noida",
                "address": "A-391, Beta 1, Greater Noida",
                "localityUrl": "ncr/beta-1-restaurants"
            },
            "timing": {
                "text": "Closes in 31 minutes",
                "color": "#e5521f"
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                    "name": "Chinese"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                    "name": "North Indian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAyM1wiXX0iXQ%3D%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/rolls/",
                    "name": "Rolls"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹600 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/food-king-beta-1-greater-noida/info",
            "clickActionDeeplink": ""
        },
        "distance": "335 m",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"19523455\",\"element_type\":\"listing\",\"rank\":156}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 20438179,
            "name": "Pizza 25",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/9/20438179/f4589bdeafe47d42772da8f86bbfb855_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/9/20438179/f4589bdeafe47d42772da8f86bbfb855_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": false
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "0",
                "rating_text": "-",
                "rating_subtitle": "Not rated",
                "rating_color": "CBCBCB",
                "votes": "1",
                "subtext": "REVIEW",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "",
                        "reviewCount": "1",
                        "reviewTextSmall": "1 Reviews",
                        "subtext": "Does not offer Dining",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Delivery",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹350 for two"
            },
            "cfo": {
                "text": "₹150 for one"
            },
            "locality": {
                "name": "Delta 1, Greater Noida",
                "address": "Jaitpur Vaispur, Delta 1, Greater Noida",
                "localityUrl": "ncr/delta-1-restaurants"
            },
            "timing": {
                "text": "Closes in 1 hour 31 minutes",
                "color": "#e5521f"
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODJcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/pizza/",
                    "name": "Pizza"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹350 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/pizza-25-delta-1-greater-noida/info",
            "clickActionDeeplink": ""
        },
        "distance": "3.2 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20438179\",\"element_type\":\"listing\",\"rank\":157}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 20791925,
            "name": "RS Kitchen",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/5/20791925/44f06339c060a87638eb1a2c2094312b_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/5/20791925/44f06339c060a87638eb1a2c2094312b_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": "https://b.zmtcdn.com/data/pictures/5/20791925/730d15bf1d7f3eb3370b9246b035253c_o2_featured_v2.jpg"
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "0",
                "rating_text": "-",
                "rating_subtitle": "Not rated",
                "rating_color": "CBCBCB",
                "votes": "0",
                "subtext": "REVIEW",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Dining",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Delivery",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹400 for two"
            },
            "cfo": {
                "text": "₹200 for one"
            },
            "locality": {
                "name": "Delta 1, Greater Noida",
                "address": "Shop 07, 4th Floor, Shivam Plaza, Delta 1, Greater Noida",
                "localityUrl": "ncr/delta-1-restaurants"
            },
            "timing": {
                "text": "",
                "color": ""
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                    "name": "North Indian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                    "name": "Chinese"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODJcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/pizza/",
                    "name": "Pizza"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzA0XCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/sandwich/",
                    "name": "Sandwich"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAyM1wiXX0iXQ%3D%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/rolls/",
                    "name": "Rolls"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/fast-food/",
                    "name": "Fast Food"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTA2NlwiXX0iXQ%3D%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/shake/",
                    "name": "Shake"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/beverages/",
                    "name": "Beverages"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹400 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/rs-kitchen-delta-1-greater-noida/info",
            "clickActionDeeplink": ""
        },
        "distance": "1.7 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20791925\",\"element_type\":\"listing\",\"rank\":158}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 20537007,
            "name": "The Pizza Hub",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/7/20537007/effec005c9d9095b73b9e3ff4dcf9b57_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/7/20537007/effec005c9d9095b73b9e3ff4dcf9b57_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": "https://b.zmtcdn.com/data/pictures/7/20537007/40e24b9eca19d13e5e1ebe600aaf2a0d_o2_featured_v2.jpg"
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "2.1",
                "rating_text": "2.1",
                "rating_subtitle": "Poor",
                "rating_color": "FF7800",
                "votes": "7",
                "subtext": "REVIEWS",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "",
                        "reviewCount": "1",
                        "reviewTextSmall": "1 Reviews",
                        "subtext": "Does not offer Dining",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "2.1",
                        "reviewCount": "6",
                        "reviewTextSmall": "6 Reviews",
                        "subtext": "6 Delivery Reviews",
                        "color": "#E23744",
                        "ratingV2": "2.1",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "orange",
                            "tint": "300"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹350 for two"
            },
            "cfo": {
                "text": "₹150 for one"
            },
            "locality": {
                "name": "Knowledge Park, Greater Noida",
                "address": "Suraj Pardhan Market, Tugalpur, Near Ansal Plaza, Knowledge Park, Greater Noida",
                "localityUrl": "ncr/knowledge-park-restaurants"
            },
            "timing": {
                "text": "Opens at 8am",
                "color": "#ab000d"
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODJcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/pizza/",
                    "name": "Pizza"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTY4XCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/burger/",
                    "name": "Burger"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzA0XCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/sandwich/",
                    "name": "Sandwich"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/fast-food/",
                    "name": "Fast Food"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTA2NlwiXX0iXQ%3D%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/shake/",
                    "name": "Shake"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹350 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/the-pizza-hub-knowledge-park-greater-noida/info",
            "clickActionDeeplink": ""
        },
        "distance": "1.8 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20537007\",\"element_type\":\"listing\",\"rank\":159}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 19621591,
            "name": "Kanha Bakery",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/1/19621591/8103d0ad718957f3fd27060d55bc1b95_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/1/19621591/8103d0ad718957f3fd27060d55bc1b95_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": "https://b.zmtcdn.com/data/pictures/1/19621591/157ef10b2be56d58b960fbfbf626b41d_o2_featured_v2.jpg"
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "4.0",
                "rating_text": "4.0",
                "rating_subtitle": "Very Good",
                "rating_color": "5BA829",
                "votes": "30",
                "subtext": "REVIEWS",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "",
                        "reviewCount": "1",
                        "reviewTextSmall": "1 Reviews",
                        "subtext": "Does not offer Dining",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "4.0",
                        "reviewCount": "29",
                        "reviewTextSmall": "29 Reviews",
                        "subtext": "29 Delivery Reviews",
                        "color": "#E23744",
                        "ratingV2": "4.0",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "green",
                            "tint": "700"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹350 for two"
            },
            "cfo": {
                "text": "₹150 for one"
            },
            "locality": {
                "name": "Sector PI, Greater Noida",
                "address": "31, Near Hanuman Mandir, Junpat, Gautam Buddha Nagar, Sector PI, Greater Noida",
                "localityUrl": "ncr/sector-pi-restaurants"
            },
            "timing": {
                "text": "",
                "color": ""
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNVwiXX0iXQ%3D%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/bakery/",
                    "name": "Bakery"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/desserts/",
                    "name": "Desserts"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹350 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/kanha-bakery-sector-pi-greater-noida/info",
            "clickActionDeeplink": ""
        },
        "distance": "5 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"19621591\",\"element_type\":\"listing\",\"rank\":160}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 20931817,
            "name": "Royal Bakery",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/7/20931817/d26b0ad5f0ae86acd7b0ca8b465a365c_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/7/20931817/d26b0ad5f0ae86acd7b0ca8b465a365c_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": "https://b.zmtcdn.com/data/pictures/7/20931817/0405442e75df0d5f35c807e4e0441bb7_o2_featured_v2.jpg"
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "0",
                "rating_text": "NEW",
                "rating_subtitle": "Not rated",
                "rating_color": "CBCBCB",
                "votes": "0",
                "subtext": "REVIEW",
                "is_new": true
            },
            "ratingNew": {
                "newlyOpenedObj": {
                    "text": "Newly Opened",
                    "color": "#FFFFFF",
                    "bgColor": "#F4A266",
                    "bgColorV2": {
                        "type": "green",
                        "tint": "100"
                    },
                    "subtitle": "OUTLET",
                    "ratingV2": "New"
                },
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Dining",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Delivery",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDelivery": true
                    }
                }
            },
            "cft": {
                "text": "₹300 for two"
            },
            "cfo": {
                "text": "₹150 for one"
            },
            "locality": {
                "name": "Omega 2, Greater Noida",
                "address": "Haldona, Gautam Budh Nagar, Omega 2, Greater Noida",
                "localityUrl": "ncr/omega-2-restaurants"
            },
            "timing": {
                "text": "",
                "color": ""
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNVwiXX0iXQ%3D%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/bakery/",
                    "name": "Bakery"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹300 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/royal-bakery-omega-2-greater-noida/info",
            "clickActionDeeplink": ""
        },
        "distance": "1.9 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20931817\",\"element_type\":\"listing\",\"rank\":161}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 20890197,
            "name": "Eat Fir Repeat",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/7/20890197/1511b04f6824bd831adac10aac158e40_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/7/20890197/1511b04f6824bd831adac10aac158e40_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": "https://b.zmtcdn.com/data/pictures/7/20890197/66df438e749e0aa18b6c4551c414b242_o2_featured_v2.jpg"
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "0",
                "rating_text": "-",
                "rating_subtitle": "Not rated",
                "rating_color": "CBCBCB",
                "votes": "2",
                "subtext": "REVIEWS",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": {
                    "text": "Newly Opened",
                    "color": "#FFFFFF",
                    "bgColor": "#F4A266",
                    "bgColorV2": {
                        "type": "green",
                        "tint": "100"
                    },
                    "subtitle": "OUTLET",
                    "ratingV2": "New"
                },
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Dining",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "",
                        "reviewCount": "2",
                        "reviewTextSmall": "2 Reviews",
                        "subtext": "Does not offer Delivery",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDelivery": true
                    }
                }
            },
            "cft": {
                "text": "₹450 for two"
            },
            "cfo": {
                "text": "₹200 for one"
            },
            "locality": {
                "name": "Gamma 1, Greater Noida",
                "address": "Shop 13, Gali 9, Guru Tegh Bahadur Market, Jagat Farm, Gamma 1, Greater Noida",
                "localityUrl": "ncr/gamma-1-restaurants"
            },
            "timing": {
                "text": "",
                "color": ""
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                    "name": "North Indian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                    "name": "Chinese"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiOTBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/street-food/",
                    "name": "Street Food"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹450 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/eat-fir-repeat-1-gamma-1-greater-noida/info",
            "clickActionDeeplink": ""
        },
        "distance": "786 m",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20890197\",\"element_type\":\"listing\",\"rank\":162}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 20399943,
            "name": "Pizza 24×7",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/3/20399943/d49d66a4c3d0c5ed98739b266f4f707e_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/3/20399943/d49d66a4c3d0c5ed98739b266f4f707e_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": "https://b.zmtcdn.com/data/pictures/3/20399943/8d55259349a583f56d540b716c249f1a_o2_featured_v2.jpg"
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "0",
                "rating_text": "-",
                "rating_subtitle": "Not rated",
                "rating_color": "CBCBCB",
                "votes": "0",
                "subtext": "REVIEW",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Dining",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Delivery",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹400 for two"
            },
            "cfo": {
                "text": "₹200 for one"
            },
            "locality": {
                "name": "Omega 2, Greater Noida",
                "address": "Shop 23, Under Ground Floor, SDS Nri Shopping Complex, Omega 2, Greater Noida",
                "localityUrl": "ncr/omega-2-restaurants"
            },
            "timing": {
                "text": "",
                "color": ""
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODJcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/pizza/",
                    "name": "Pizza"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                    "name": "North Indian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                    "name": "Chinese"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹400 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/pizza-24-7-omega-2-greater-noida/info",
            "clickActionDeeplink": ""
        },
        "distance": "2.3 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20399943\",\"element_type\":\"listing\",\"rank\":163}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 19628228,
            "name": "Pizza 1st",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/8/19628228/b53fb3457cc5b598755a252c0ea92c18_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/8/19628228/b53fb3457cc5b598755a252c0ea92c18_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": "https://b.zmtcdn.com/data/pictures/8/19628228/813f33c33fec3a4865cc825d53a41634_o2_featured_v2.jpg"
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "0",
                "rating_text": "-",
                "rating_subtitle": "Not rated",
                "rating_color": "CBCBCB",
                "votes": "3",
                "subtext": "REVIEWS",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Dining",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "",
                        "reviewCount": "3",
                        "reviewTextSmall": "3 Reviews",
                        "subtext": "Does not offer Delivery",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹250 for two"
            },
            "cfo": {
                "text": "₹100 for one"
            },
            "locality": {
                "name": "Omega 2, Greater Noida",
                "address": "Amit Nagar, Sadarpur Pari Chauk, Omega 2, Greater Noida",
                "localityUrl": "ncr/omega-2-restaurants"
            },
            "timing": {
                "text": "Closes in 1 hour 31 minutes",
                "color": "#e5521f"
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODJcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/pizza/",
                    "name": "Pizza"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹250 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/pizza-1st-omega-2-greater-noida/info",
            "clickActionDeeplink": ""
        },
        "distance": "1.8 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"19628228\",\"element_type\":\"listing\",\"rank\":164}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 20893347,
            "name": "Nikunj Premium Cakes",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/7/20893347/751caa5e8d203eedd489218c470f57be_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/7/20893347/751caa5e8d203eedd489218c470f57be_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": "https://b.zmtcdn.com/data/pictures/7/20893347/ad5473cccb941bc31a95bef01e669fc4_o2_featured_v2.jpg"
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "0",
                "rating_text": "-",
                "rating_subtitle": "Not rated",
                "rating_color": "CBCBCB",
                "votes": "1",
                "subtext": "REVIEW",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": {
                    "text": "Newly Opened",
                    "color": "#FFFFFF",
                    "bgColor": "#F4A266",
                    "bgColorV2": {
                        "type": "green",
                        "tint": "100"
                    },
                    "subtitle": "OUTLET",
                    "ratingV2": "New"
                },
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Dining",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "",
                        "reviewCount": "1",
                        "reviewTextSmall": "1 Reviews",
                        "subtext": "Does not offer Delivery",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDelivery": true
                    }
                }
            },
            "cft": {
                "text": "₹300 for two"
            },
            "cfo": {
                "text": "₹150 for one"
            },
            "locality": {
                "name": "Omega 2, Greater Noida",
                "address": "Village Haldona, Knowledge Park-2, Omega 2, Greater Noida",
                "localityUrl": "ncr/omega-2-restaurants"
            },
            "timing": {
                "text": "",
                "color": ""
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNVwiXX0iXQ%3D%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/bakery/",
                    "name": "Bakery"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹300 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/nikunj-premium-cakes-omega-2-greater-noida/info",
            "clickActionDeeplink": ""
        },
        "distance": "1.9 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a488e798-c898-4218-9e99-2f681daf8086\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"dineout\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20893347\",\"element_type\":\"listing\",\"rank\":165}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    }
]