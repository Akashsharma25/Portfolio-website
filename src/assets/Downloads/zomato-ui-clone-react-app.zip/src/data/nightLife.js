export const nightLife = [
        {
            "type": "restaurant",
            "info": {
                "resId": 301085,
                "name": "PCO",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/5/301085/b7448337447f54f39e8ce0ef1d2bbed4_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/5/301085/b7448337447f54f39e8ce0ef1d2bbed4_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/5/301085/6b1c72d79c0aa8106928ad256f239619_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.4",
                    "rating_text": "4.4",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "867",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "4.6",
                            "reviewCount": "798",
                            "reviewTextSmall": "798 Reviews",
                            "subtext": "798 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "4.6",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "800"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "4.2",
                            "reviewCount": "69",
                            "reviewTextSmall": "69 Reviews",
                            "subtext": "69 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "4.2",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹2,000 for two"
                },
                "cfo": {
                    "text": "₹650 for one"
                },
                "locality": {
                    "name": "Vasant Vihar, New Delhi",
                    "address": "D-4, D Block Market, Vasant Vihar, New Delhi",
                    "localityUrl": "ncr/vasant-vihar-delhi-restaurants"
                },
                "timing": {
                    "text": "Opens at 5:30pm",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/italian/",
                        "name": "Italian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/fast-food/",
                        "name": "Fast Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/continental/",
                        "name": "Continental"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹2,000 for two"
                }
            },
            "order": [],
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/pco-vasant-vihar-new-delhi/info",
                "clickActionDeeplink": ""
            },
            "distance": "35.6 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"301085\",\"element_type\":\"listing\",\"rank\":490}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [
                {
                    "type": "booking_cta",
                    "text": "Book a Table",
                    "clickUrl": "/ncr/pco-vasant-vihar-new-delhi/book"
                }
            ],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 20394198,
                "name": "Growl Curated Kitchen & Bar",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/8/20394198/2465b48e77d9be7d37284b09587d1297_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/8/20394198/2465b48e77d9be7d37284b09587d1297_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": false
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.8",
                    "rating_text": "4.8",
                    "rating_subtitle": "Excellent",
                    "rating_color": "3F7E00",
                    "votes": "260",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "4.8",
                            "reviewCount": "260",
                            "reviewTextSmall": "260 Reviews",
                            "subtext": "260 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "4.8",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "800"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Delivery",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹3,500 for two"
                },
                "cfo": {
                    "text": "₹650 for one"
                },
                "locality": {
                    "name": "Gardens Galleria Mall, Sector 38, Noida",
                    "address": "Shop 311 And 312, 2nd Floor, Gardens Galleria Mall, Sector 38, Noida",
                    "localityUrl": "ncr/restaurants/in/gardens-galleria-mall-sector-38"
                },
                "timing": {
                    "text": "Opens at 12noon",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/continental/",
                        "name": "Continental"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/fast-food/",
                        "name": "Fast Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiOTVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/thai/",
                        "name": "Thai"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiM1wiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/asian/",
                        "name": "Asian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiOTk4XCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/salad/",
                        "name": "Salad"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/italian/",
                        "name": "Italian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/desserts/",
                        "name": "Desserts"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹3,500 for two"
                }
            },
            "order": [],
            "gold": {
                "instant": 25,
                "welcome_offer": false,
                "gold_offer": true,
                "text": "Flat",
                "offerValue": "25% OFF",
                "isGoldIcon": true
            },
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/growl-curated-kitchen-bar-sector-38-noida/info",
                "clickActionDeeplink": ""
            },
            "distance": "20.5 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20394198\",\"element_type\":\"listing\",\"rank\":491}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [
                {
                    "type": "booking_cta",
                    "text": "Book a Table",
                    "clickUrl": "/ncr/growl-curated-kitchen-bar-sector-38-noida/book"
                }
            ],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 20457564,
                "name": "Decode Lounge And Bar",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/4/20457564/3acb42ed096c1af72efc41f8d37ce0d5_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/4/20457564/3acb42ed096c1af72efc41f8d37ce0d5_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": false
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.4",
                    "rating_text": "4.4",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "114",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "4.4",
                            "reviewCount": "114",
                            "reviewTextSmall": "114 Reviews",
                            "subtext": "114 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "4.4",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Delivery",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹1,800 for two"
                },
                "cfo": {
                    "text": "₹650 for one"
                },
                "locality": {
                    "name": "Sector 53, Gurgaon",
                    "address": "1st Floor, Emaar The Palm Spring Plaza, Sector 53, Gurgaon",
                    "localityUrl": "ncr/sector-53-gurgaon-gurugram-restaurants"
                },
                "timing": {
                    "text": "Opens at 12noon",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/fast-food/",
                        "name": "Fast Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiOTk4XCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/salad/",
                        "name": "Salad"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTQzXCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/health-food/",
                        "name": "Healthy Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                        "name": "Chinese"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/continental/",
                        "name": "Continental"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiM1wiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/asian/",
                        "name": "Asian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/italian/",
                        "name": "Italian"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹1,800 for two"
                }
            },
            "order": [],
            "gold": {
                "instant": 50,
                "welcome_offer": false,
                "gold_offer": true,
                "text": "Flat",
                "offerValue": "50% OFF",
                "isGoldIcon": true
            },
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/decode-lounge-and-bar-sector-53-gurgaon/info",
                "clickActionDeeplink": ""
            },
            "distance": "40.1 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20457564\",\"element_type\":\"listing\",\"rank\":492}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [
                {
                    "type": "booking_cta",
                    "text": "Book a Table",
                    "clickUrl": "/ncr/decode-lounge-and-bar-sector-53-gurgaon/book"
                }
            ],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 20252594,
                "name": "Kitchen District - Hyatt Centric",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/4/20252594/3f1317d4e92745b6e60c64ed8af7a158_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/4/20252594/3f1317d4e92745b6e60c64ed8af7a158_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/4/20252594/a8ce10c2a6b08e0d8b5136f28a4aa1a3_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.2",
                    "rating_text": "4.2",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "126",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "4.2",
                            "reviewCount": "126",
                            "reviewTextSmall": "126 Reviews",
                            "subtext": "126 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "4.2",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Delivery",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹3,500 for two"
                },
                "cfo": {
                    "text": "₹650 for one"
                },
                "locality": {
                    "name": "Janakpuri, New Delhi",
                    "address": "Centre Complex, Janakpuri, New Delhi",
                    "localityUrl": "ncr/janakpuri-delhi-restaurants"
                },
                "timing": {
                    "text": "Opens at 7am",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiM1wiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/asian/",
                        "name": "Asian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/italian/",
                        "name": "Italian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/continental/",
                        "name": "Continental"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNzVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/mughlai/",
                        "name": "Mughlai"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiN1wiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/biryani/",
                        "name": "Biryani"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/desserts/",
                        "name": "Desserts"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/beverages/",
                        "name": "Beverages"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹3,500 for two"
                }
            },
            "order": [],
            "gold": {
                "instant": 20,
                "welcome_offer": false,
                "gold_offer": true,
                "text": "Flat",
                "offerValue": "20% OFF",
                "isGoldIcon": true
            },
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/kitchen-district-hyatt-centric-1-janakpuri-new-delhi/info",
                "clickActionDeeplink": ""
            },
            "distance": "45 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20252594\",\"element_type\":\"listing\",\"rank\":493}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [
                {
                    "type": "booking_cta",
                    "text": "Book a Table",
                    "clickUrl": "/ncr/kitchen-district-hyatt-centric-1-janakpuri-new-delhi/book"
                },
                {
                    "type": "chain_cta",
                    "text": "View all outlets",
                    "clickUrl": "/ncr/restaurants/kitchen-district-hyatt-regency?subzone=171277&category=3"
                }
            ],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 65,
                "name": "Drums of Heaven",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/5/65/120a84e1c62afdb79eacd7f28c56ba4c_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/5/65/120a84e1c62afdb79eacd7f28c56ba4c_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/5/65/d0162e212d3fe7ec39c7611def102694_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.4",
                    "rating_text": "4.4",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "3,855",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "4.4",
                            "reviewCount": "941",
                            "reviewTextSmall": "941 Reviews",
                            "subtext": "941 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "4.4",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "4.3",
                            "reviewCount": "2,914",
                            "reviewTextSmall": "2,914 Reviews",
                            "subtext": "2,914 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "4.3",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹2,000 for two"
                },
                "cfo": {
                    "text": "₹650 for one"
                },
                "locality": {
                    "name": "Green Park, New Delhi",
                    "address": "S 14, Green Park Extension, Green Park, New Delhi",
                    "localityUrl": "ncr/green-park-delhi-restaurants"
                },
                "timing": {
                    "text": "Opens at 12noon",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                        "name": "Chinese"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiOTVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/thai/",
                        "name": "Thai"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiM1wiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/asian/",
                        "name": "Asian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODNcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/sea-food/",
                        "name": "Seafood"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/desserts/",
                        "name": "Desserts"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹2,000 for two"
                }
            },
            "order": [],
            "gold": {
                "instant": 20,
                "welcome_offer": false,
                "gold_offer": true,
                "text": "Flat",
                "offerValue": "20% OFF",
                "isGoldIcon": true
            },
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/drums-of-heaven-green-park-new-delhi/info",
                "clickActionDeeplink": ""
            },
            "distance": "30.7 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"65\",\"element_type\":\"listing\",\"rank\":494}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [
                {
                    "type": "booking_cta",
                    "text": "Book a Table",
                    "clickUrl": "/ncr/drums-of-heaven-green-park-new-delhi/book"
                },
                {
                    "type": "chain_cta",
                    "text": "View all outlets",
                    "clickUrl": "/ncr/restaurants/drums-of-heaven?subzone=171277&category=3"
                }
            ],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 20688993,
                "name": "Playboy Beer Garden",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/3/20688993/a0afa67f3d9c88834699cc3ed613387c_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/3/20688993/a0afa67f3d9c88834699cc3ed613387c_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/3/20688993/107bca5ab73d487a00ce325795a638d1_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.0",
                    "rating_text": "4.0",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "16",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "4.0",
                            "reviewCount": "16",
                            "reviewTextSmall": "16 Reviews",
                            "subtext": "16 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "4.0",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Delivery",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹1,800 for two"
                },
                "cfo": {
                    "text": "₹650 for one"
                },
                "locality": {
                    "name": "Sector 45, Gurgaon",
                    "address": "Unitech Commercial Tower 2, Sector 45, Gurgaon",
                    "localityUrl": "ncr/sector-45-gurgaon-gurugram-restaurants"
                },
                "timing": {
                    "text": "Opens tomorrow at 5pm",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/continental/",
                        "name": "Continental"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiM1wiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/asian/",
                        "name": "Asian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                        "name": "Chinese"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/italian/",
                        "name": "Italian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/beverages/",
                        "name": "Beverages"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹1,800 for two"
                }
            },
            "order": [],
            "gold": {
                "instant": 20,
                "welcome_offer": false,
                "gold_offer": true,
                "text": "Flat",
                "offerValue": "20% OFF",
                "isGoldIcon": true
            },
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/playboy-beer-garden-sector-45-gurgaon/info",
                "clickActionDeeplink": ""
            },
            "distance": "44 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20688993\",\"element_type\":\"listing\",\"rank\":495}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [
                {
                    "type": "booking_cta",
                    "text": "Book a Table",
                    "clickUrl": "/ncr/playboy-beer-garden-sector-45-gurgaon/book"
                }
            ],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 18208920,
                "name": "Quaff Brewing Co.",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/0/18208920/0e5199beb860a07f7e61fe612b530cc4_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/0/18208920/0e5199beb860a07f7e61fe612b530cc4_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": false
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.3",
                    "rating_text": "4.3",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "1,243",
                    "subtext": "REVIEW",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "4.3",
                            "reviewCount": "1,243",
                            "reviewTextSmall": "1,243 Reviews",
                            "subtext": "1,243 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "4.3",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Delivery",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹3,000 for two"
                },
                "cfo": {
                    "text": "₹650 for one"
                },
                "locality": {
                    "name": "Cyber Hub, DLF Cyber City, Gurgaon",
                    "address": "Tower B, Building 10, Cyber Hub, DLF Cyber City, Gurgaon",
                    "localityUrl": "ncr/restaurants/in/cyber-hub-dlf-cyber-city"
                },
                "timing": {
                    "text": "Opens at 12noon",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                        "name": "Chinese"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODJcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/pizza/",
                        "name": "Pizza"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTA2NFwiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/pasta/",
                        "name": "Pasta"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹3,000 for two"
                }
            },
            "order": [],
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/quaff-brewing-co-dlf-cyber-city-gurgaon/info",
                "clickActionDeeplink": ""
            },
            "distance": "41 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"18208920\",\"element_type\":\"listing\",\"rank\":496}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 20509755,
                "name": "Touch Kitchen & Bar",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/5/20509755/b9c4f3c1bcfe3b8e8140f10ea917f647_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/chains/5/20509755/b9c4f3c1bcfe3b8e8140f10ea917f647_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/5/20509755/04b5dd298ea382be270d89f7ddbba7b5_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.4",
                    "rating_text": "4.4",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "253",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "4.4",
                            "reviewCount": "217",
                            "reviewTextSmall": "217 Reviews",
                            "subtext": "217 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "4.4",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "4.3",
                            "reviewCount": "36",
                            "reviewTextSmall": "36 Reviews",
                            "subtext": "36 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "4.3",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹1,500 for two"
                },
                "cfo": {
                    "text": "₹650 for one"
                },
                "locality": {
                    "name": "Sector 135, Noida",
                    "address": "Plot 93 & 94, Sector 136, Near Sector 135, Noida",
                    "localityUrl": "ncr/sector-135-restaurants"
                },
                "timing": {
                    "text": "Opens at 12noon",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                        "name": "Chinese"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTY4XCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/burger/",
                        "name": "Burger"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiOTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/street-food/",
                        "name": "Street Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/desserts/",
                        "name": "Desserts"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹1,500 for two"
                }
            },
            "order": [],
            "gold": {
                "instant": 15,
                "welcome_offer": false,
                "gold_offer": true,
                "text": "Flat",
                "offerValue": "15% OFF",
                "isGoldIcon": true
            },
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/touch-kitchen-bar-1-sector-135-noida/info",
                "clickActionDeeplink": ""
            },
            "distance": "10.4 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20509755\",\"element_type\":\"listing\",\"rank\":497}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [
                {
                    "type": "booking_cta",
                    "text": "Book a Table",
                    "clickUrl": "/ncr/touch-kitchen-bar-1-sector-135-noida/book"
                }
            ],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 19855115,
                "name": "On Air Bar & Kitchen",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/5/19855115/924f69c38ca91f1492618b6a6ab2ce4c_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/5/19855115/924f69c38ca91f1492618b6a6ab2ce4c_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/5/19855115/bc1d8f2ab76471b192125412587116c1_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.3",
                    "rating_text": "4.3",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "640",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "4.3",
                            "reviewCount": "417",
                            "reviewTextSmall": "417 Reviews",
                            "subtext": "417 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "4.3",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "4.2",
                            "reviewCount": "223",
                            "reviewTextSmall": "223 Reviews",
                            "subtext": "223 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "4.2",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹2,500 for two"
                },
                "cfo": {
                    "text": "₹650 for one"
                },
                "locality": {
                    "name": "Sector 81, Faridabad",
                    "address": "CR-301, Puri Business Hub, 81 High Street, Sector 81, Faridabad",
                    "localityUrl": "ncr/sector-81-faridabad-restaurants"
                },
                "timing": {
                    "text": "Opens at 12noon",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/italian/",
                        "name": "Italian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiM1wiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/asian/",
                        "name": "Asian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/continental/",
                        "name": "Continental"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTc4XCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/kebab/",
                        "name": "Kebab"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiN1wiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/biryani/",
                        "name": "Biryani"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/desserts/",
                        "name": "Desserts"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/beverages/",
                        "name": "Beverages"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹2,500 for two"
                }
            },
            "order": [],
            "gold": {
                "instant": 15,
                "welcome_offer": false,
                "gold_offer": true,
                "text": "Flat",
                "offerValue": "15% OFF",
                "isGoldIcon": true
            },
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/on-air-bar-kitchen-1-sector-81-faridabad/info",
                "clickActionDeeplink": ""
            },
            "distance": "19.1 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"19855115\",\"element_type\":\"listing\",\"rank\":498}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [
                {
                    "type": "booking_cta",
                    "text": "Book a Table",
                    "clickUrl": "/ncr/on-air-bar-kitchen-1-sector-81-faridabad/book"
                }
            ],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 18628250,
                "name": "360° -  The Oberoi",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/0/18628250/1733a9fdfa923449dfcf824a5799b725_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/0/18628250/1733a9fdfa923449dfcf824a5799b725_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": false
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.3",
                    "rating_text": "4.3",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "260",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "4.3",
                            "reviewCount": "260",
                            "reviewTextSmall": "260 Reviews",
                            "subtext": "260 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "4.3",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Delivery",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹6,000 for two"
                },
                "cfo": {
                    "text": "₹650 for one"
                },
                "locality": {
                    "name": "The Oberoi, Dr. Zakir Hussain Marg, New Delhi",
                    "address": "The Oberoi, Dr. Zakir Hussain Marg, New Delhi",
                    "localityUrl": "ncr/restaurants/in/the-oberoi-dr-zakir-hussain-marg"
                },
                "timing": {
                    "text": "Opens at 7am",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/italian/",
                        "name": "Italian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/continental/",
                        "name": "Continental"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNzBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/mediterranean/",
                        "name": "Mediterranean"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹6,000 for two"
                }
            },
            "order": [],
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/360°-the-oberoi-zakir-hussain-marg-new-delhi/info",
                "clickActionDeeplink": ""
            },
            "distance": "29.2 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"18628250\",\"element_type\":\"listing\",\"rank\":499}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [
                {
                    "type": "booking_cta",
                    "text": "Book a Table",
                    "clickUrl": "/ncr/360°-the-oberoi-zakir-hussain-marg-new-delhi/book"
                }
            ],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 18291200,
                "name": "Town Hall",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/2/307802/c379f180868eba7fe114896e919e15c1_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/chains/2/307802/c379f180868eba7fe114896e919e15c1_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/0/18291200/2e3a8e5a7e0e77d893aaeb1ce21af385_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.2",
                    "rating_text": "4.2",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "686",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "4.4",
                            "reviewCount": "524",
                            "reviewTextSmall": "524 Reviews",
                            "subtext": "524 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "4.4",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "4.0",
                            "reviewCount": "162",
                            "reviewTextSmall": "162 Reviews",
                            "subtext": "162 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "4.0",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹2,500 for two"
                },
                "cfo": {
                    "text": "₹650 for one"
                },
                "locality": {
                    "name": "DLF Horizon Center, Gurgaon",
                    "address": "T-2/105, Plaza Level, Two Horizon Centre, Sector 43, Gurgaon",
                    "localityUrl": "ncr/restaurants/in/dlf-horizon-center"
                },
                "timing": {
                    "text": "Opens at 12noon",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNjBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/japanese/",
                        "name": "Japanese"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiOTVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/thai/",
                        "name": "Thai"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/italian/",
                        "name": "Italian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiM1wiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/asian/",
                        "name": "Asian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODJcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/pizza/",
                        "name": "Pizza"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzhcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/european/",
                        "name": "European"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹2,500 for two"
                }
            },
            "order": [],
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/town-hall-sector-43/info",
                "clickActionDeeplink": ""
            },
            "distance": "40.3 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"18291200\",\"element_type\":\"listing\",\"rank\":500}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [
                {
                    "type": "booking_cta",
                    "text": "Book a Table",
                    "clickUrl": "/ncr/town-hall-sector-43/book"
                },
                {
                    "type": "chain_cta",
                    "text": "View all outlets",
                    "clickUrl": "/ncr/restaurants/town-hall?subzone=171277&category=3"
                }
            ],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 307060,
                "name": "The Beer Cafe - BIGGIE",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/0/307060/b0f399c0edb46dde814267a8824ae1b7_featured_v2.jpg",
                    "urlWithParams": "https://b.zmtcdn.com/data/pictures/0/307060/b0f399c0edb46dde814267a8824ae1b7_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/0/307060/52e09a1732fc67f668d706f4f254edb6_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.1",
                    "rating_text": "4.1",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "1,796",
                    "subtext": "REVIEW",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "4.1",
                            "reviewCount": "1,780",
                            "reviewTextSmall": "1,780 Reviews",
                            "subtext": "1,780 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "4.1",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDining": false
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "4.0",
                            "reviewCount": "16",
                            "reviewTextSmall": "16 Reviews",
                            "subtext": "16 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "4.0",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Ratings",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹1,800 for two"
                },
                "cfo": {
                    "text": "₹650 for one"
                },
                "locality": {
                    "name": "Middle Circle, Connaught Place, New Delhi",
                    "address": "D-2, Inner Circle, Connaught Place, New Delhi",
                    "localityUrl": "ncr/restaurants/in/middle-circle-connaught-place"
                },
                "timing": {
                    "text": "Opens at 11am",
                    "color": "#ab000d"
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjI3XCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/bar-food/",
                        "name": "Bar Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODJcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/pizza/",
                        "name": "Pizza"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/italian/",
                        "name": "Italian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTc4XCJdfSJd",
                        "url": "https://www.zomato.com/ncr/restaurants/kebab/",
                        "name": "Kebab"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                        "name": "Chinese"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiM1wiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/asian/",
                        "name": "Asian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzVcIl19Il0%3D",
                        "url": "https://www.zomato.com/ncr/restaurants/continental/",
                        "name": "Continental"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹1,800 for two"
                }
            },
            "order": [],
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/ncr/the-beer-cafe-biggie-connaught-place-new-delhi/info",
                "clickActionDeeplink": ""
            },
            "distance": "32.8 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"307060\",\"element_type\":\"listing\",\"rank\":501}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [
                {
                    "type": "booking_cta",
                    "text": "Book a Table",
                    "clickUrl": "/ncr/the-beer-cafe-biggie-connaught-place-new-delhi/book"
                }
            ],
            "promoOffer": "",
            "checkBulkOffers": false,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": []
        }
    ,
    {
        "type": "restaurant",
        "info": {
            "resId": 7624,
            "name": "Dee Choice Restaurant & Bar - Dee Marks Hotel & Resort",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/4/7624/a6178627a3498f972c7af2ab47d0ba57_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/4/7624/a6178627a3498f972c7af2ab47d0ba57_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": "https://b.zmtcdn.com/data/pictures/4/7624/26f90a1e4ba948b9a5a8d40223f6870f_o2_featured_v2.jpg"
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "3.8",
                "rating_text": "3.8",
                "rating_subtitle": "Good",
                "rating_color": "9ACD32",
                "votes": "20",
                "subtext": "REVIEWS",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "3.8",
                        "reviewCount": "19",
                        "reviewTextSmall": "19 Reviews",
                        "subtext": "19 Dining Reviews",
                        "color": "#1C1C1C",
                        "ratingV2": "3.8",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "green",
                            "tint": "600"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "",
                        "reviewCount": "1",
                        "reviewTextSmall": "1 Reviews",
                        "subtext": "Does not offer Delivery",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹2,000 for two"
            },
            "cfo": {
                "text": "₹800 for one"
            },
            "locality": {
                "name": "Dee Marks Hotel & Resort, Mahipalpur, New Delhi",
                "address": "Khasra 365/2, 368/2 PT, 379/394, NH-8, Rangpuri, Mahipalpur, Vasant Vihar, New Delhi",
                "localityUrl": "ncr/restaurants/in/dee-marks-hotel-resort-new-delhi"
            },
            "timing": {
                "text": "",
                "color": ""
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                    "name": "North Indian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                    "name": "Chinese"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiN1wiXX0iXQ%3D%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/biryani/",
                    "name": "Biryani"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/fast-food/",
                    "name": "Fast Food"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiOTBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/street-food/",
                    "name": "Street Food"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹2,000 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/dee-choice-restaurant-bar-dee-marks-hotel-resort-vasant-vihar-new-delhi/info",
            "clickActionDeeplink": ""
        },
        "distance": "39 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"7624\",\"element_type\":\"listing\",\"rank\":142}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 20685115,
            "name": "House Of Boho",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/5/20685115/e5c42cbca87d3c7d09a05201c2f29c94_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/5/20685115/e5c42cbca87d3c7d09a05201c2f29c94_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": false
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "4.3",
                "rating_text": "4.3",
                "rating_subtitle": "Very Good",
                "rating_color": "5BA829",
                "votes": "271",
                "subtext": "REVIEWS",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "4.3",
                        "reviewCount": "271",
                        "reviewTextSmall": "271 Reviews",
                        "subtext": "271 Dining Reviews",
                        "color": "#1C1C1C",
                        "ratingV2": "4.3",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "green",
                            "tint": "700"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Delivery",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹3,200 for two"
            },
            "cfo": {
                "text": "₹1,300 for one"
            },
            "locality": {
                "name": "Ansal Plaza Mall, Khel Gaon Marg, New Delhi",
                "address": "Ansal Plaza, Hudco Place, Andrews Ganj, Khel Gaon Marg, Near August Kranti Marg, South Extension 2, New Delhi",
                "localityUrl": "ncr/restaurants/in/ansal-plaza-mall-khel-gaon-marg"
            },
            "timing": {
                "text": "Opens at 12noon",
                "color": "#ab000d"
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNzBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/mediterranean/",
                    "name": "Mediterranean"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiM1wiXX0iXQ%3D%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/asian/",
                    "name": "Asian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTc3XCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/sushi/",
                    "name": "Sushi"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/italian/",
                    "name": "Italian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODJcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/pizza/",
                    "name": "Pizza"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTA2NFwiXX0iXQ%3D%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/pasta/",
                    "name": "Pasta"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                    "name": "North Indian"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹3,200 for two"
            }
        },
        "order": [],
        "gold": {
            "instant": 10,
            "welcome_offer": false,
            "gold_offer": true,
            "text": "Flat",
            "offerValue": "10% OFF",
            "isGoldIcon": true
        },
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/house-of-boho-south-extension-2-new-delhi/info",
            "clickActionDeeplink": ""
        },
        "distance": "29.2 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20685115\",\"element_type\":\"listing\",\"rank\":143}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [
            {
                "type": "booking_cta",
                "text": "Book a Table",
                "clickUrl": "/ncr/house-of-boho-south-extension-2-new-delhi/book"
            }
        ],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 312601,
            "name": "Openhouse Cafe",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/1/312601/bf489c5c9e97d932126a9770d0ee1ee4_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/1/312601/bf489c5c9e97d932126a9770d0ee1ee4_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": false
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "4.2",
                "rating_text": "4.2",
                "rating_subtitle": "Very Good",
                "rating_color": "5BA829",
                "votes": "6,358",
                "subtext": "REVIEWS",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "4.2",
                        "reviewCount": "6,358",
                        "reviewTextSmall": "6,358 Reviews",
                        "subtext": "6,358 Dining Reviews",
                        "color": "#1C1C1C",
                        "ratingV2": "4.2",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "green",
                            "tint": "700"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Delivery",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹2,000 for two"
            },
            "cfo": {
                "text": "₹800 for one"
            },
            "locality": {
                "name": "Connaught Place, New Delhi",
                "address": "C-37, Connaught Place, New Delhi",
                "localityUrl": "ncr/connaught-place-delhi-restaurants"
            },
            "timing": {
                "text": "Opens at 12noon",
                "color": "#ab000d"
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/continental/",
                    "name": "Continental"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                    "name": "Chinese"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                    "name": "North Indian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNzVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/mughlai/",
                    "name": "Mughlai"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODJcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/pizza/",
                    "name": "Pizza"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/beverages/",
                    "name": "Beverages"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/desserts/",
                    "name": "Desserts"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjI3XCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/bar-food/",
                    "name": "Bar Food"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹2,000 for two"
            }
        },
        "order": [],
        "gold": {
            "instant": 15,
            "welcome_offer": false,
            "gold_offer": true,
            "text": "Flat",
            "offerValue": "15% OFF",
            "isGoldIcon": true
        },
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/openhouse-cafe-connaught-place-new-delhi/info",
            "clickActionDeeplink": ""
        },
        "distance": "32.8 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"312601\",\"element_type\":\"listing\",\"rank\":144}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [
            {
                "type": "booking_cta",
                "text": "Book a Table",
                "clickUrl": "/ncr/openhouse-cafe-connaught-place-new-delhi/book"
            }
        ],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 20795950,
            "name": "Lord Club",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/0/20795950/fd320599e093bd7522a3cf7aa0ffe7ac_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/0/20795950/fd320599e093bd7522a3cf7aa0ffe7ac_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": false
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "0",
                "rating_text": "-",
                "rating_subtitle": "Not rated",
                "rating_color": "CBCBCB",
                "votes": "3",
                "subtext": "REVIEWS",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "",
                        "reviewCount": "3",
                        "reviewTextSmall": "3 Reviews",
                        "subtext": "Does not offer Dining",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Delivery",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹1,500 for two"
            },
            "cfo": {
                "text": "₹600 for one"
            },
            "locality": {
                "name": "Naraina, New Delhi",
                "address": "B-226, 4th Floor, Block B, Industrial Area Phase 1, Naraina, New Delhi",
                "localityUrl": "ncr/naraina-delhi-restaurants"
            },
            "timing": {
                "text": "",
                "color": ""
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjI3XCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/bar-food/",
                    "name": "Bar Food"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹1,500 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/lord-club-naraina-new-delhi/info",
            "clickActionDeeplink": ""
        },
        "distance": "40 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20795950\",\"element_type\":\"listing\",\"rank\":145}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 20243538,
            "name": "Somewhere Restaurant & Bar",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/8/20243538/94767ef7a9f9fc6c3d98ada4cfaad9d5_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/8/20243538/94767ef7a9f9fc6c3d98ada4cfaad9d5_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": "https://b.zmtcdn.com/data/pictures/chains/8/20243538/79c2eafc07229f5c4439b93b69660695_o2_featured_v2.jpg"
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "4.2",
                "rating_text": "4.2",
                "rating_subtitle": "Very Good",
                "rating_color": "5BA829",
                "votes": "1,055",
                "subtext": "REVIEW",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "4.4",
                        "reviewCount": "1,044",
                        "reviewTextSmall": "1,044 Reviews",
                        "subtext": "1,044 Dining Reviews",
                        "color": "#1C1C1C",
                        "ratingV2": "4.4",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "green",
                            "tint": "700"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "3.9",
                        "reviewCount": "11",
                        "reviewTextSmall": "11 Reviews",
                        "subtext": "11 Delivery Reviews",
                        "color": "#E23744",
                        "ratingV2": "3.9",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "green",
                            "tint": "600"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹2,600 for two"
            },
            "cfo": {
                "text": "₹1,050 for one"
            },
            "locality": {
                "name": "Middle Circle, Connaught Place, New Delhi",
                "address": "H-10, Ground Floor, H Block, Laxmi Building, Connaught Place, New Delhi",
                "localityUrl": "ncr/restaurants/in/middle-circle-connaught-place"
            },
            "timing": {
                "text": "Opens at 12noon",
                "color": "#ab000d"
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiM1wiXX0iXQ%3D%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/asian/",
                    "name": "Asian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNjZcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/lebanese/",
                    "name": "Lebanese"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/continental/",
                    "name": "Continental"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                    "name": "North Indian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/fast-food/",
                    "name": "Fast Food"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjI3XCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/bar-food/",
                    "name": "Bar Food"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/desserts/",
                    "name": "Desserts"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/beverages/",
                    "name": "Beverages"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹2,600 for two"
            }
        },
        "order": [],
        "gold": {
            "instant": 20,
            "welcome_offer": false,
            "gold_offer": true,
            "text": "Flat",
            "offerValue": "20% OFF",
            "isGoldIcon": true
        },
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/somewhere-restaurant-bar-connaught-place-new-delhi/info",
            "clickActionDeeplink": ""
        },
        "distance": "33 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20243538\",\"element_type\":\"listing\",\"rank\":146}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [
            {
                "type": "booking_cta",
                "text": "Book a Table",
                "clickUrl": "/ncr/somewhere-restaurant-bar-connaught-place-new-delhi/book"
            }
        ],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 20843058,
            "name": "Qavalli",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/8/20843058/b6acaf687039f73a98f518ec70a3f909_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/8/20843058/b6acaf687039f73a98f518ec70a3f909_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": false
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "3.9",
                "rating_text": "3.9",
                "rating_subtitle": "Good",
                "rating_color": "9ACD32",
                "votes": "59",
                "subtext": "REVIEWS",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "3.9",
                        "reviewCount": "59",
                        "reviewTextSmall": "59 Reviews",
                        "subtext": "59 Dining Reviews",
                        "color": "#1C1C1C",
                        "ratingV2": "3.9",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "green",
                            "tint": "600"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Delivery",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹2,000 for two"
            },
            "cfo": {
                "text": "₹800 for one"
            },
            "locality": {
                "name": "Worldmark 1, Aerocity, New Delhi",
                "address": "6, Lower Ground Floor, Worldmark 1, Aerocity, New Delhi",
                "localityUrl": "ncr/restaurants/in/worldmark-1-aerocity"
            },
            "timing": {
                "text": "Opens at 12noon",
                "color": "#ab000d"
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                    "name": "North Indian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNzVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/mughlai/",
                    "name": "Mughlai"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/desserts/",
                    "name": "Desserts"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/beverages/",
                    "name": "Beverages"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹2,000 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/qavalli-aerocity-new-delhi/info",
            "clickActionDeeplink": ""
        },
        "distance": "38.6 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20843058\",\"element_type\":\"listing\",\"rank\":147}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 19012642,
            "name": "Rooh",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/2/19012642/b9816b00c33a50a8f8ca7a31a4cdbcb8_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/2/19012642/b9816b00c33a50a8f8ca7a31a4cdbcb8_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": "https://b.zmtcdn.com/data/pictures/2/19012642/b77543105c04f9ce96e01a76a08afc7f_o2_featured_v2.jpg"
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "4.5",
                "rating_text": "4.5",
                "rating_subtitle": "Excellent",
                "rating_color": "3F7E00",
                "votes": "681",
                "subtext": "REVIEWS",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "4.5",
                        "reviewCount": "681",
                        "reviewTextSmall": "681 Reviews",
                        "subtext": "681 Dining Reviews",
                        "color": "#1C1C1C",
                        "ratingV2": "4.5",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "green",
                            "tint": "800"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Delivery",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹4,500 for two"
            },
            "cfo": {
                "text": "₹1,800 for one"
            },
            "locality": {
                "name": "Ambawatta One Complex, Mehrauli, New Delhi",
                "address": "H-5/1, Ambawatta One Complex, Kalkadas Marg, Mehrauli, New Delhi",
                "localityUrl": "ncr/restaurants/in/ambawatta-one-complex-mehrauli"
            },
            "timing": {
                "text": "Opens at 12:30pm",
                "color": "#ab000d"
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAxOFwiXX0iXQ%3D%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/modern-indian/",
                    "name": "Modern Indian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                    "name": "North Indian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/desserts/",
                    "name": "Desserts"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/beverages/",
                    "name": "Beverages"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹4,500 for two"
            }
        },
        "order": [],
        "gold": {
            "instant": 10,
            "welcome_offer": false,
            "gold_offer": true,
            "text": "Flat",
            "offerValue": "10% OFF",
            "isGoldIcon": true
        },
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/rooh-mehrauli-new-delhi/info",
            "clickActionDeeplink": ""
        },
        "distance": "31.9 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"19012642\",\"element_type\":\"listing\",\"rank\":148}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [
            {
                "type": "booking_cta",
                "text": "Book a Table",
                "clickUrl": "/ncr/rooh-mehrauli-new-delhi/book"
            }
        ],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 20532535,
            "name": "Club Obello",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/5/20532535/7278a970f6e7d078f2e770c725a14cb9_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/5/20532535/7278a970f6e7d078f2e770c725a14cb9_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": false
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "0",
                "rating_text": "-",
                "rating_subtitle": "Not rated",
                "rating_color": "CBCBCB",
                "votes": "3",
                "subtext": "REVIEWS",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "",
                        "reviewCount": "2",
                        "reviewTextSmall": "2 Reviews",
                        "subtext": "Does not offer Dining",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "",
                        "reviewCount": "1",
                        "reviewTextSmall": "1 Reviews",
                        "subtext": "Does not offer Delivery",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹8,500 for two"
            },
            "cfo": {
                "text": "₹3,400 for one"
            },
            "locality": {
                "name": "Connaught Place, New Delhi",
                "address": "Janpath, Ashoka Road, Connaught Place, New Delhi",
                "localityUrl": "ncr/connaught-place-delhi-restaurants"
            },
            "timing": {
                "text": "",
                "color": ""
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTc3XCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/sushi/",
                    "name": "Sushi"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiM1wiXX0iXQ%3D%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/asian/",
                    "name": "Asian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/continental/",
                    "name": "Continental"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/fast-food/",
                    "name": "Fast Food"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODJcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/pizza/",
                    "name": "Pizza"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹8,500 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/club-obello-connaught-place-new-delhi/info",
            "clickActionDeeplink": ""
        },
        "distance": "32.4 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20532535\",\"element_type\":\"listing\",\"rank\":149}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 20750236,
            "name": "The Smog Lounge & Cafe",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/6/20750236/365af20969f2ef3c0424d25ba4bcbac3_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/6/20750236/365af20969f2ef3c0424d25ba4bcbac3_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": false
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "0",
                "rating_text": "-",
                "rating_subtitle": "Not rated",
                "rating_color": "CBCBCB",
                "votes": "0",
                "subtext": "REVIEW",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Dining",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "",
                        "reviewCount": "0",
                        "reviewTextSmall": "0 Reviews",
                        "subtext": "Does not offer Delivery",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹1,400 for two"
            },
            "cfo": {
                "text": "₹600 for one"
            },
            "locality": {
                "name": "Sector 37, Faridabad",
                "address": "12/2A, Rao Complex, Sarai Khawaja Village, Sector 37, Faridabad",
                "localityUrl": "ncr/sector-37-faridabad-restaurants"
            },
            "timing": {
                "text": "",
                "color": ""
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/continental/",
                    "name": "Continental"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/italian/",
                    "name": "Italian"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹1,400 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/the-smog-lounge-cafe-sector-37-faridabad/info",
            "clickActionDeeplink": ""
        },
        "distance": "19.7 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20750236\",\"element_type\":\"listing\",\"rank\":150}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 18216901,
            "name": "Unplugged Courtyard",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/1/18216901/ef9e31ea5cdc7a78cf4c67f426ebacdd_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/1/18216901/ef9e31ea5cdc7a78cf4c67f426ebacdd_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": "https://b.zmtcdn.com/data/pictures/chains/1/18216901/940786f2ccf51ec35328e2f43cfb751d_o2_featured_v2.jpg"
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "4.1",
                "rating_text": "4.1",
                "rating_subtitle": "Very Good",
                "rating_color": "5BA829",
                "votes": "5,712",
                "subtext": "REVIEWS",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "4.1",
                        "reviewCount": "5,694",
                        "reviewTextSmall": "5,694 Reviews",
                        "subtext": "5,694 Dining Reviews",
                        "color": "#1C1C1C",
                        "ratingV2": "4.1",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "green",
                            "tint": "700"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "4.0",
                        "reviewCount": "18",
                        "reviewTextSmall": "18 Reviews",
                        "subtext": "18 Delivery Reviews",
                        "color": "#E23744",
                        "ratingV2": "4.0",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "green",
                            "tint": "700"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹2,000 for two"
            },
            "cfo": {
                "text": "₹800 for one"
            },
            "locality": {
                "name": "Connaught Place, New Delhi",
                "address": "23/7, L Block, Middle Circle, Connaught Place, New Delhi",
                "localityUrl": "ncr/connaught-place-delhi-restaurants"
            },
            "timing": {
                "text": "Opens at 12noon",
                "color": "#ab000d"
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                    "name": "North Indian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                    "name": "Chinese"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTQyXCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/turkish/",
                    "name": "Turkish"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTc3XCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/sushi/",
                    "name": "Sushi"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiOTk4XCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/salad/",
                    "name": "Salad"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODJcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/pizza/",
                    "name": "Pizza"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiN1wiXX0iXQ%3D%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/biryani/",
                    "name": "Biryani"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/beverages/",
                    "name": "Beverages"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹2,000 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/unplugged-courtyard-connaught-place-new-delhi/info",
            "clickActionDeeplink": ""
        },
        "distance": "32.8 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"18216901\",\"element_type\":\"listing\",\"rank\":151}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [
            {
                "type": "booking_cta",
                "text": "Book a Table",
                "clickUrl": "/ncr/unplugged-courtyard-connaught-place-new-delhi/book"
            },
            {
                "type": "chain_cta",
                "text": "View all outlets",
                "clickUrl": "/ncr/restaurants/unplugged-courtyard?subzone=171277&category=3"
            }
        ],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 18204820,
            "name": "Themis Barbeque House",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/0/18204820/3c0fd979123367a02885ef16467345ae_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/0/18204820/3c0fd979123367a02885ef16467345ae_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": "https://b.zmtcdn.com/data/pictures/0/18204820/0694d325984f89fd67808c828a48bf47_o2_featured_v2.jpg"
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "4.2",
                "rating_text": "4.2",
                "rating_subtitle": "Very Good",
                "rating_color": "5BA829",
                "votes": "3,860",
                "subtext": "REVIEWS",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "4.2",
                        "reviewCount": "3,859",
                        "reviewTextSmall": "3,859 Reviews",
                        "subtext": "3,859 Dining Reviews",
                        "color": "#1C1C1C",
                        "ratingV2": "4.2",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "green",
                            "tint": "700"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "",
                        "reviewCount": "1",
                        "reviewTextSmall": "1 Reviews",
                        "subtext": "Does not offer Delivery",
                        "color": "",
                        "ratingV2": "-",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "grey",
                            "tint": "500"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹1,800 for two"
            },
            "cfo": {
                "text": "₹750 for one"
            },
            "locality": {
                "name": "Netaji Subhash Place, New Delhi",
                "address": "Property 251, Second Floor Aggarwal Millennium Tower, E-1, 2, 3, Saraswati Vihar, North West, Pitampura, Netaji Subhash Place, New Delhi",
                "localityUrl": "ncr/netaji-subhash-place-delhi-restaurants"
            },
            "timing": {
                "text": "Opens at 11:30am",
                "color": "#ab000d"
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                    "name": "North Indian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/italian/",
                    "name": "Italian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNzVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/mughlai/",
                    "name": "Mughlai"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiOTk4XCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/salad/",
                    "name": "Salad"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/desserts/",
                    "name": "Desserts"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/beverages/",
                    "name": "Beverages"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹1,800 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/themis-barbeque-house-netaji-subhash-place-new-delhi/info",
            "clickActionDeeplink": ""
        },
        "distance": "42.3 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"18204820\",\"element_type\":\"listing\",\"rank\":152}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [
            {
                "type": "booking_cta",
                "text": "Book a Table",
                "clickUrl": "/ncr/themis-barbeque-house-netaji-subhash-place-new-delhi/book"
            }
        ],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    },
    {
        "type": "restaurant",
        "info": {
            "resId": 20504225,
            "name": "Anardana",
            "image": {
                "url": "https://b.zmtcdn.com/data/pictures/5/20504225/f3736730661e7787a7a4f5c771fc06b9_featured_v2.jpg",
                "urlWithParams": "https://b.zmtcdn.com/data/pictures/5/20504225/f3736730661e7787a7a4f5c771fc06b9_featured_v2.jpg?fit=around%7C108%3A108&crop=108%3A108%3B%2A%2C%2A"
            },
            "o2FeaturedImage": {
                "url": "https://b.zmtcdn.com/data/pictures/chains/0/18966900/5af378219cd5d9156e7fbe359ba59130_o2_featured_v2.jpg"
            },
            "rating": {
                "has_fake_reviews": 0,
                "aggregate_rating": "4.3",
                "rating_text": "4.3",
                "rating_subtitle": "Very Good",
                "rating_color": "5BA829",
                "votes": "1,526",
                "subtext": "REVIEW",
                "is_new": false
            },
            "ratingNew": {
                "newlyOpenedObj": null,
                "suspiciousReviewObj": null,
                "ratings": {
                    "DINING": {
                        "rating_type": "DINING",
                        "rating": "4.5",
                        "reviewCount": "1,088",
                        "reviewTextSmall": "1,088 Reviews",
                        "subtext": "1,088 Dining Reviews",
                        "color": "#1C1C1C",
                        "ratingV2": "4.5",
                        "subtitle": "DINING",
                        "sideSubTitle": "Dining Ratings",
                        "bgColorV2": {
                            "type": "green",
                            "tint": "800"
                        },
                        "newOnDining": false
                    },
                    "DELIVERY": {
                        "rating_type": "DELIVERY",
                        "rating": "4.1",
                        "reviewCount": "438",
                        "reviewTextSmall": "438 Reviews",
                        "subtext": "438 Delivery Reviews",
                        "color": "#E23744",
                        "ratingV2": "4.1",
                        "subtitle": "DELIVERY",
                        "sideSubTitle": "Delivery Ratings",
                        "bgColorV2": {
                            "type": "green",
                            "tint": "700"
                        },
                        "newOnDelivery": false
                    }
                }
            },
            "cft": {
                "text": "₹2,400 for two"
            },
            "cfo": {
                "text": "₹1,000 for one"
            },
            "locality": {
                "name": "M3M International Financial Center, Gurgaon",
                "address": "Shop R 3006 & R 3007, Ground Floor, M3M International Financial Center, Sector 66, Gurgaon",
                "localityUrl": "ncr/restaurants/in/m3m-international-financial-center"
            },
            "timing": {
                "text": "Opens at 11:30am",
                "color": "#ab000d"
            },
            "cuisine": [
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/north-indian/",
                    "name": "North Indian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNzVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/mughlai/",
                    "name": "Mughlai"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/chinese/",
                    "name": "Chinese"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTVcIl19Il0%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/italian/",
                    "name": "Italian"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTA1MVwiXX0iXQ%3D%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/momos/",
                    "name": "Momos"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiN1wiXX0iXQ%3D%3D",
                    "url": "https://www.zomato.com/ncr/restaurants/biryani/",
                    "name": "Biryani"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/desserts/",
                    "name": "Desserts"
                },
                {
                    "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                    "url": "https://www.zomato.com/ncr/restaurants/beverages/",
                    "name": "Beverages"
                }
            ],
            "should_ban_ugc": false,
            "costText": {
                "text": "₹2,400 for two"
            }
        },
        "order": [],
        "gold": [],
        "takeaway": [],
        "cardAction": {
            "text": "",
            "clickUrl": "/ncr/anardana-sector-66-gurgaon/info",
            "clickActionDeeplink": ""
        },
        "distance": "44.8 km",
        "isPromoted": false,
        "promotedText": "",
        "trackingData": [
            {
                "table_name": "zsearch_events_log",
                "payload": "{\"search_id\":\"a56b2a28-5034-48c1-b804-237a74056562\",\"location_type\":\"delivery_cell\",\"location_id\":\"4110918374958039040\",\"page_type\":\"nightlife\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"20504225\",\"element_type\":\"listing\",\"rank\":153}",
                "event_names": {
                    "tap": "{\"action\":\"tap\"}",
                    "impression": "{\"action\":\"impression\"}"
                }
            }
        ],
        "allCTA": [
            {
                "type": "booking_cta",
                "text": "Book a Table",
                "clickUrl": "/ncr/anardana-sector-66-gurgaon/book"
            },
            {
                "type": "chain_cta",
                "text": "View all outlets",
                "clickUrl": "/ncr/restaurants/anardana-1?subzone=171277&category=3"
            }
        ],
        "promoOffer": "",
        "checkBulkOffers": false,
        "bulkOffers": [],
        "isDisabled": false,
        "bottomContainers": []
    }
]