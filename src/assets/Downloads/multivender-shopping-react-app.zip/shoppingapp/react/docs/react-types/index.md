---
title: React Types
---

`@types/react` makes some types available that can be very useful. Here's a list in alphabetical order with links to the detailed reference pages.

- [`ComponentProps<ElementType>`](/docs/react-types/ComponentProps)
- [`ReactNode`](/docs/react-types/ReactNode)
