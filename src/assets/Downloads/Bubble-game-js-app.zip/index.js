var timer = 60;
var score = 0;
var hitrn;

const increaseScore = ()=>{
    score+=10;
    document.querySelector("#incresescore").textContent=score;
}
const getNewHit = ()=>{
    hitrn = Math.floor(Math.random()*10);
    document.querySelector("#hit").textContent=hitrn;
}
const makeBubble = () => {
  var clutter = "";

  for (let i = 1; i < 91; i++) {
    var rn = Math.floor(Math.random() * 10);
    clutter += `<div class="bubble">${rn}</div>`;
  }

  document.querySelector("#pbottom").innerHTML = clutter;
};
const runTimer = ()=>{
    setInterval(function (){
        if(timer > 0){
            timer--;
            document.querySelector("#timerval").textContent=timer;
            
        }else{
            clearInterval(timer);
            document.querySelector("#pbottom").innerHTML=`<h1 class="endgame"> Game Over and Your Score is ${score}</h1>`;
        }
    }, 1000);
}

document.querySelector("#pbottom").addEventListener("click", function(dets){
    var hit = Number(dets.target.textContent);
    if(hit===hitrn){
        increaseScore();
        getNewHit();
        makeBubble();
    }
});


getNewHit();
runTimer();
makeBubble();
